const searchInput = document.querySelector("#search");
const cards = [...document.querySelectorAll(".game-card")];
const count = document.querySelector("#result-count");
let activeCategory = "Todos";

function filterCards() {
  const query = searchInput.value.trim().toLocaleLowerCase("es");
  let visible = 0;
  cards.forEach(card => {
    const matchesText = `${card.dataset.title} ${card.dataset.category} ${card.dataset.search}`.toLocaleLowerCase("es").includes(query);
    const matchesCategory = activeCategory === "Todos" || card.dataset.category === activeCategory;
    card.hidden = !(matchesText && matchesCategory);
    if (!card.hidden) visible++;
  });
  count.textContent = `${visible} ${visible === 1 ? "juego" : "juegos"}`;
}
searchInput.addEventListener("input", filterCards);
document.querySelectorAll("[data-filter]").forEach(button => {
  button.addEventListener("click", () => {
    activeCategory = button.dataset.filter;
    document.querySelectorAll("[data-filter]").forEach(b => b.classList.toggle("active", b === button));
    filterCards();
    document.querySelector("#juegos").scrollIntoView({behavior:"smooth", block:"start"});
  });
});

const infoModal = document.querySelector("#info-modal");
document.querySelectorAll(".launch-info").forEach(button => button.addEventListener("click", () => {
  document.querySelector("#modal-title").textContent = button.dataset.game || "Juego";
  infoModal.hidden = false;
}));
function closeInfo(){ infoModal.hidden = true; }
document.querySelector("#close-info").addEventListener("click", closeInfo);
document.querySelector("#close-info-cta").addEventListener("click", closeInfo);
infoModal.addEventListener("click", e => { if(e.target === infoModal) closeInfo(); });

const ticModal = document.querySelector("#tic-modal");
const boardEl = document.querySelector("#tic-board");
const statusEl = document.querySelector("#tic-status");
let board, player, finished;
function startTic() {
  board = Array(9).fill("");
  player = "X";
  finished = false;
  boardEl.innerHTML = "";
  board.forEach((_, i) => {
    const cell = document.createElement("button");
    cell.className = "tic-cell";
    cell.setAttribute("aria-label", `Casilla ${i+1}`);
    cell.addEventListener("click", () => playCell(i, cell));
    boardEl.appendChild(cell);
  });
  statusEl.textContent = "Turno de X";
}
function playCell(i, cell) {
  if (finished || board[i]) return;
  board[i] = player;
  cell.textContent = player;
  cell.setAttribute("aria-label", `Casilla ${i+1}: ${player}`);
  const wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  if (wins.some(line => line.every(index => board[index] === player))) {
    statusEl.textContent = `¡Gana ${player}!`;
    finished = true;
  } else if (board.every(Boolean)) {
    statusEl.textContent = "¡Empate!";
    finished = true;
  } else {
    player = player === "X" ? "O" : "X";
    statusEl.textContent = `Turno de ${player}`;
  }
}
document.querySelectorAll(".launch-tic").forEach(button => button.addEventListener("click", () => {
  startTic(); ticModal.hidden = false;
}));
document.querySelector("#close-tic").addEventListener("click", () => ticModal.hidden = true);
document.querySelector("#reset-tic").addEventListener("click", startTic);
ticModal.addEventListener("click", e => { if(e.target === ticModal) ticModal.hidden = true; });
document.addEventListener("keydown", e => { if(e.key === "Escape"){ closeInfo(); ticModal.hidden = true; } });
