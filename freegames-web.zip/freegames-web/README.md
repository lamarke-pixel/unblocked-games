# FreeGames — web de juegos gratis

Plantilla estática en español, adaptable a móvil, sin frameworks ni costes de hosting.

## Qué incluye
- Diseño oscuro estilo portal de juegos.
- Búsqueda y filtros por categoría.
- Snow Rider 3D enlazado a su sitio: https://snowrider.com/
- Mini juego Tres en raya jugable dentro de la web.
- Tarjetas de muestra para ampliar el catálogo.

Las tarjetas marcadas como “Próximamente” son ejemplos visuales, no juegos funcionales todavía. Para añadirlos, usa juegos HTML5 propios o contenido cuyo creador permita incrustar/enlazar. No copies archivos de juegos ni imágenes con copyright sin permiso. Snow Rider se abre en su web original; no se copia ni se incrusta.

## Publicar gratis con GitHub Pages
1. Descomprime `freegames-web.zip`.
2. Crea una cuenta en https://github.com/ si aún no tienes una.
3. Pulsa **New repository**. Ponle un nombre, por ejemplo `freegames-web`, y elige **Public**.
4. Dentro del repositorio, pulsa **Add file → Upload files**.
5. Sube `index.html`, `styles.css` y `script.js` (y este README si quieres). `index.html` debe quedar en la raíz, no dentro de otra carpeta.
6. Pulsa **Commit changes**.
7. En el repositorio, abre **Settings → Pages**.
8. En **Build and deployment**, selecciona **Deploy from a branch**. Elige la rama `main` y la carpeta `/(root)`, y pulsa **Save**.
9. Espera unos minutos. En esa misma pantalla aparecerá el enlace de tu web, normalmente `https://TU-USUARIO.github.io/freegames-web/`.
10. Abre el enlace en móvil y ordenador y prueba la búsqueda, las categorías, el mini juego y Snow Rider.

Guía oficial: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Cómo añadir juegos reales
- Si es tu propio juego HTML5, sube sus archivos a una carpeta, por ejemplo `juegos/mi-juego/`, y enlázalo desde una tarjeta.
- Si el desarrollador proporciona un iframe oficial, sigue sus condiciones y revisa que permita tu uso.
- Si solo existe en una web externa, enlaza a la página original con `target="_blank"` y `rel="noopener noreferrer"`.
- No hay que pagar por GitHub Pages para un sitio público estático; un dominio personalizado es opcional y normalmente cuesta dinero.
